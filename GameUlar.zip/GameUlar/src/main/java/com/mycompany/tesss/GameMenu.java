package com.mycompany.tesss;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GameMenu extends JPanel implements ActionListener {
    private JFrame frame;
    private int highestLevelUnlocked = 1;
    private int boardWidth;
    private int boardHeight;
    private JComboBox<String> difficultyComboBox;

    public GameMenu(JFrame frame, int boardWidth, int boardHeight) {
        this.frame = frame;
        this.boardWidth = boardWidth;
        this.boardHeight = boardHeight;

        setLayout(new GridBagLayout());
        setBackground(Color.BLACK);
        setPreferredSize(new Dimension(boardWidth, boardHeight));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel title = new JLabel("Snake Game");
        title.setFont(new Font("Arial", Font.BOLD, 30));
        title.setForeground(Color.MAGENTA);
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(title, gbc);

        gbc.gridy++;
        add(createButton("Start Game"), gbc);

        gbc.gridy++;
        add(createDifficultyComboBox(), gbc);
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.PLAIN, 20));
        button.setForeground(Color.WHITE);
        button.setBackground(Color.MAGENTA);
        button.setFocusPainted(false);
        button.addActionListener(this);
        return button;
    }

    private JComboBox<String> createDifficultyComboBox() {
        String[] difficulties = {"Easy", "Normal", "Hard"};
        difficultyComboBox = new JComboBox<>(difficulties);
        difficultyComboBox.setFont(new Font("Arial", Font.PLAIN, 20));
        difficultyComboBox.setForeground(Color.WHITE);
        difficultyComboBox.setBackground(Color.MAGENTA);
        return difficultyComboBox;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if (command.equals("Start Game")) {
            startGame();
        }
    }

    private void startGame() {
        SwingUtilities.invokeLater(() -> {
            String selectedDifficulty = (String) difficultyComboBox.getSelectedItem();
            frame.getContentPane().removeAll();
            SnakeGame game = new SnakeGame(boardWidth, boardHeight, this, selectedDifficulty);
            frame.add(game);
            frame.revalidate();
            frame.repaint();
            frame.pack();
            game.requestFocusInWindow();
        });
    }

    void returnToMenu() {
        frame.getContentPane().removeAll();
        GameMenu menu = new GameMenu(frame, boardWidth, boardHeight);
        frame.add(menu);
        frame.revalidate();
        frame.repaint();
        frame.pack();
    }
}
