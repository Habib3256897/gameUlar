package com.mycompany.tesss;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;
import javax.sound.sampled.*;
import java.io.IOException;
import java.net.URL;

public class SnakeGame extends JPanel implements ActionListener, KeyListener {

    private int boardWidth;
    private int boardHeight;
    private int tileSize = 20;

    private Tile snakeHead;
    private ArrayList<Tile> snakeBody;
    private Tile food;
    private Random random;
    private Timer gameLoop;
    private int velocityX;
    private int velocityY;
    private boolean gameOver = false;
    private int score = 0;
    private GameMenu menu;
    private ImageIcon apple;
    private String selectedDifficulty;

    public SnakeGame(int boardWidth, int boardHeight, GameMenu menu, String difficulty) {
        this.boardWidth = boardWidth;
        this.boardHeight = boardHeight;
        this.menu = menu;
        this.selectedDifficulty = difficulty;
        setPreferredSize(new Dimension(this.boardWidth, this.boardHeight));
        setBackground(Color.black);
        setFocusable(true);
        addKeyListener(this);

        snakeHead = new Tile(5, 5);
        snakeBody = new ArrayList<>();
        random = new Random();
        placeSnake();

        food = new Tile(10, 10);
        random = new Random();
        placeFood();

        velocityX = 0;
        velocityY = 0;

        int delay = getDelayBasedOnDifficulty(selectedDifficulty);
        gameLoop = new Timer(delay, this);
        gameLoop.start();

        apple = new ImageIcon(getClass().getClassLoader().getResource("apple.png"));

        requestFocusInWindow();

    }

    private int getDelayBasedOnDifficulty(String difficulty) {
        switch (difficulty) {
            case "Easy":
                return 150;
            case "Normal":
                return 100;
            case "Hard":
                return 50;
            default:
                return 100;
        }
    }
    
    private void playGameOverSound() {
        try {
            URL url = getClass().getClassLoader().getResource("game_over.wav");
            if (url == null) {
                throw new IOException("Cannot find game_over.wav");
            }

            AudioInputStream audioIn = AudioSystem.getAudioInputStream(url);

            Clip clip = AudioSystem.getClip();
            clip.open(audioIn);

            clip.start();
        } catch (UnsupportedAudioFileException | LineUnavailableException | IOException e) {
            e.printStackTrace();
        }
    }
    
    private void playEatFoodSound() {
        try {
            URL url = getClass().getClassLoader().getResource("bite_sound.wav");
            if (url == null) {
                throw new IOException("Cannot find eat_food.wav");
            }

            AudioInputStream audioIn = AudioSystem.getAudioInputStream(url);

            Clip clip = AudioSystem.getClip();
            clip.open(audioIn);

            clip.start();
        } catch (UnsupportedAudioFileException | LineUnavailableException | IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    public void draw(Graphics g) {
        g.setColor(Color.BLACK);
        g.fillRect(food.x * tileSize, food.y * tileSize, tileSize, tileSize);

        g.setColor(Color.MAGENTA);
        g.fillRect(snakeHead.x * tileSize, snakeHead.y * tileSize, tileSize, tileSize);

        for (Tile snakePart : snakeBody) {
            g.fillRect(snakePart.x * tileSize, snakePart.y * tileSize, tileSize, tileSize);
        }

        g.setFont(new Font("Arial", Font.PLAIN, 16));
        if (gameOver) {
            g.setColor(Color.red);
            g.drawString("Game Over: " + snakeBody.size(), tileSize - 16, tileSize);
        } else {
            g.drawString("Score: " + snakeBody.size(), tileSize - 16, tileSize);
        }
        g.drawImage(apple.getImage(), food.x * tileSize, food.y * tileSize, tileSize, tileSize, this);
    }

    public void placeSnake() {
        snakeHead.x = random.nextInt(boardWidth / tileSize);
        snakeHead.y = random.nextInt(boardHeight / tileSize);
    }

    public void placeFood() {
        food.x = random.nextInt(boardWidth / tileSize);
        food.y = random.nextInt(boardHeight / tileSize);
    }

    public boolean collision(Tile tile1, Tile tile2) {
        return tile1.x == tile2.x && tile1.y == tile2.y;
    }

    public void move() {
        if (collision(snakeHead, food)) {
            snakeBody.add(new Tile(food.x, food.y));
            placeFood();
            score++;
            playEatFoodSound();
        }

        for (int i = snakeBody.size() - 1; i >= 0; i--) {
            Tile snakePart = snakeBody.get(i);
            if (i == 0) {
                snakePart.x = snakeHead.x;
                snakePart.y = snakeHead.y;
            } else {
                Tile prevSnakePart = snakeBody.get(i - 1);
                snakePart.x = prevSnakePart.x;
                snakePart.y = prevSnakePart.y;
            }
        }

        snakeHead.x += velocityX;
        snakeHead.y += velocityY;

        if (snakeHead.x < 0) {
            snakeHead.x = boardWidth / tileSize - 1;
        } else if (snakeHead.x >= boardWidth / tileSize) {
            snakeHead.x = 0;
        } else if (snakeHead.y < 0) {
            snakeHead.y = boardHeight / tileSize - 1;
        } else if (snakeHead.y >= boardHeight / tileSize) {
            snakeHead.y = 0;
        }

        for (Tile snakePart : snakeBody) {
            if (collision(snakeHead, snakePart)) {
                gameOver = true;
            }
        }

        gameLoop.setDelay(getDelayBasedOnDifficulty(selectedDifficulty)); 
        repaint();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!gameOver) {
            move();
        } else {
            gameLoop.stop();
            playGameOverSound();

            int result = JOptionPane.showOptionDialog(this, "Game Over! Score: " + snakeBody.size(), "Game Over",
                    JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null,
                    new String[]{"Restart", "Return to Menu"}, "Restart");
            if (result == JOptionPane.YES_OPTION) {
                restartGame();
            } else {
                menu.returnToMenu();
            }
        }
    }

    private void restartGame() {
        JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
        frame.getContentPane().removeAll();
        SnakeGame game = new SnakeGame(boardWidth, boardHeight, menu, selectedDifficulty); 
        frame.add(game);
        frame.pack();
        game.requestFocusInWindow();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP:
                if (velocityY != 1) {
                    velocityX = 0;
                    velocityY = -1;
                }
                break;
            case KeyEvent.VK_DOWN:
                if (velocityY != -1) {
                    velocityX = 0;
                    velocityY = 1;
                }
                break;
            case KeyEvent.VK_LEFT:
                if (velocityX != 1) {
                    velocityX = -1;
                    velocityY = 0;
                }
                break;
            case KeyEvent.VK_RIGHT:
                if (velocityX != -1) {
                    velocityX = 1;
                    velocityY = 0;
                }
                break;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    private class Tile {
        int x;
        int y;

        Tile(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }
}
